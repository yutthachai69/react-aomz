import './Mycss.css';
function Buuton({text}) {
    return ( 
        <>
         <button className='btn01'>{text}</button>
        </>
     );
}

export default Buuton;